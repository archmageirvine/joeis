#include "def.h"
#include "macro.h"

ANFANG
scan(INTEGER,a);
fakul(a,b);
println(b);
ENDE
